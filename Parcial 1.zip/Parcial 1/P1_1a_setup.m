% Parámetros
L = 1.21;
g = 10;
a1 = 2.5;
a2 = 5;
%%%%%%%%%%%
a3 = (a1 + a2) / (a2*L);

% Condiciones iniciales
x0 = [0, 0];
y0 = [0, 0];
z0 = [0, 0];