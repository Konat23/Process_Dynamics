% Parámetros
g = 10;
m1 = 10;
m2 = 30;
k = 30;
r1 = 2;
%%%%%%%%%%%


% Condiciones iniciales
x0 = [0, 0];
y0 = [0, 0];
z0 = [0, 0];